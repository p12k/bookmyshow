package com.bookmyshow.BookMyshow.dao;

import org.springframework.data.repository.CrudRepository;

import com.bookmyshow.BookMyshow.bean.Movies;

public interface MoviesDao extends CrudRepository<Movies, Integer> {
	
}
