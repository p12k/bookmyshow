package com.bean;

public class BookingDetails {

	String movieName;
	String theaterName;
	String movieShow;
	String seatNumber;
	String ticketPrice;
	
	public String getMovieName() {
		return movieName;
	}
	
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	
	public String getTheaterName() {
		return theaterName;
	}
	
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	
	public String getMovieShow() {
		return movieShow;
	}
	
	public void setMovieShow(String movieShow) {
		this.movieShow = movieShow;
	}
		
	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public String getTicketPrice() {
		return ticketPrice;
	}
	
	public void setTicketPrice(String ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	
}
