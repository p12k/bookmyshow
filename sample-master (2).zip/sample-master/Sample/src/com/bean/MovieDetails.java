package com.bean;

public class MovieDetails {
	
	String moviename;
	String actor;
	String languages;
	String rating;
	int price;
	
	public String getMoviename() {
		return moviename;
	}
	
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	
	
	public String getActor() {
		return actor;
	}
	
	public void setActor(String actor) {
		this.actor = actor;
	}
	
	
	public String getLanguages() {
		return languages;
	}
	
	public void setLanguages(String languages) {
		this.languages = languages;
	}
	
	
	public String getRating() {
		return rating;
	}
	
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
